/* 
* CSCE 1040 Homework 3 
* Section: 002
* Name: Annie Gomez
* UNT Email: anniegomez@my.unt.edu
* Date submitted: April 25, 2022
 
*File name: patrons.cpp
*Description:  Write  here  an  explanation  of  the  code  that  is  written  in  this  file,  *include  the 
objective of the functions written, any required inputs and the  *correct outputs. This will be an 
explanation in a high level of the code you are *writing in each code file. 
*/ 

#include <iostream>
#include <string>
#include <vector>
#include <iterator>
#include <algorithm>
#include <ctime>
#include <iomanip>
#include "patrons.h"
using namespace std;

//default constructor definition

Patrons::Patrons(){}

//member function definitions

void Patrons::addPatron(){
	string tempName;
	int tempID;

	cout << "***Adding New Patron***" << endl;
	Patron tempPatron;

	cout << "Enter patron name:" << endl;
	cin.ignore();
	getline(cin, tempName);
	tempPatron.SetName(tempName);

	cout << "Enter Patron ID:" << endl;
	cin >> tempID;
	tempPatron.SetPatronID(tempID);

	tempPatron.SetBalance(0);
	tempPatron.SetBooksOut(0);

	pVect.push_back(tempPatron);
}

void Patrons::editPatron(){

	char choice;
	int editPatron;
	string tempName;
	int tempID;
	bool editCont = true;
	char editChoice;

	cout << "Enter the ID of the Patron you wish to edit: " << endl;
	cin >> editPatron;

	for(iter = pVect.begin(); iter != pVect.end(); iter++){
		if((iter->GetPatronID()) == editPatron){
			cout << "Patron Found!" << endl;
			while(editCont == true){
				cout << "What would you like to edit?" << endl;
				cout << "n - Patron Name" << endl;
				cout << "i - Patron ID" << endl;
				cout << "q - Quit Editing Menu" << endl;
				cout << "Enter the character for the corresponding choice you would like to take: " << endl;

				cin >> editChoice;

				switch(editChoice){
					case 'n':{
						cout << "Enter the new name of the Patron:" << endl;
						cin.ignore();
						getline(cin, tempName);
						iter->SetName(tempName);
						cout << "Successfully updated Patron name." << endl;
						break;

					}//end of 'n' (edit name) case

					case 'i':{
						cout << "Enter the new ID of the Patron:" << endl;
						cin >> tempID;
						iter->SetPatronID(tempID);
						cout << "Successfully updated Patron ID" << endl;
						break;

					}//end of 'i' (edit ID) case

					case 'q':{
						cout << endl;
						cout << "Exiting Edit Menu" << endl;
						cout << endl;
						editCont = false;
						break;
					}//end of 'q' (quit) case

					default:{
						cout << "Wrong choice. Please try again." << endl;
						break;
					}//end default case

				}//end switch case

			}//end while loop
		}else{
			cout << "Patron was not found, sorry." << endl;
			break;
		}//if else
	}//for loop end


cout << "Editing function currently under repair. Please try again later." << endl;
}

void Patrons::deletePatron(){
	int byePatronID;
	cout << "Enter the ID of the Patron you want to delete: " << endl;
	cin >> byePatronID;

	for(iter = pVect.begin(); iter != pVect.end(); iter++){
		if((iter->GetPatronID()) == byePatronID){
			pVect.erase(iter);
			cout << "Patron " << byePatronID << " deleted successfully." << endl;
			break;
		}
	}
}

void Patrons::searchPatron(){
	int searchID;
	cout << "Enter the ID of the Patron you want to Find:" << endl;
	cin >> searchID;

	for(iter = pVect.begin(); iter != pVect.end(); iter++){
		if((iter->GetPatronID()) == searchID){
			break;
		}
	}

	if(iter != pVect.end()){
		cout << endl;
		cout << "Patron " << searchID << " exists in the library." << endl;
		cout << endl;
	}else{
		cout << "Patron was not found." << endl;
		cout << endl;
	}
}

void Patrons::printPatron(){
	int searchID;
	cout << "Enter the ID of the Patron you want to Find:" << endl;
	cin >> searchID;

	for(iter = pVect.begin(); iter != pVect.end(); iter++){
		if((iter->GetPatronID()) == searchID){
			cout << endl;
			cout << "*****PATRON INFORMATION*****" << endl;
			cout << "Patron Name: " << iter->GetName() << endl;
			cout << "Patron ID: " << iter->GetPatronID() << endl;
			cout << "Current Balance: " << iter->GetBalance() << endl;
			cout << "Current Number of Books Checked Out: " << iter->GetBooksOut() << endl;
			cout << endl;
		}
	}
}

void Patrons::printAllPatrons(){
	if(pVect.empty() == true){
		cout << "There are no patrons in the library system." << endl;
	}else{
	for(iter = pVect.begin(); iter != pVect.end(); iter++){
		cout << endl;
		cout << "*****PATRON LIBRARY*****" << endl;
		cout << "Patron Name: " << iter->GetName() << endl;
		cout << "Patron ID: " << iter->GetPatronID() << endl;
		cout << "Current Balance: " << iter->GetBalance() << endl;
		cout << "Current Number of Books Checked Out: " << iter->GetBooksOut() << endl;
		cout << endl;
	}//for loop
	}//if
}


