/*
* CSCE 1040 Homework 3
* Section: 002
* Name: Annie Gomez
* UNT Email: anniegomez@my.unt.edu
* Date submitted: April 25, 2022

*File name: loan.cpp
*Description:  Write  here  an  explanation  of  the  code  that  is  written  in  this  file,  *include  the 
objective of the functions written, any required inputs and the  *correct outputs. This will be an 
explanation in a high level of the code you are *writing in each code file.
*/

#include <iostream>
#include <ctime>
#include "loan.h"
using namespace std;

//default constructor definition

Loan::Loan(){
	LoanID = 0;
	BookID = 0;
	PatronID = 0;
	dueDate = time(NULL);
}

//Loan ID set and get
void Loan::SetLoanID(int Lid){
	LoanID = Lid;
}

int Loan::GetLoanID(){
	return LoanID;
}

//BookID set and get
void Loan::SetBookID(int Bid){
	BookID = Bid;
}

int Loan::GetBookID(){
	return BookID;
}

//PatronID set and get
void Loan::SetPatronID(int Pid){
	PatronID = Pid;
}

int Loan::GetPatronID(){
	return PatronID;
}

//dueDate set and get
void Loan::SetDueDate(time_t due){
	dueDate = due;
}

time_t Loan::GetDueDate(){
	return dueDate;
}

//number of rechecks set and get
void Loan::SetNumChecks(int plus){
	plus = numReChecks;
}

int Loan::GetNumChecks(){
	return numReChecks;
}
