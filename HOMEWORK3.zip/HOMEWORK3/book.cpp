/* 
* CSCE 1040 Homework 3 
* Section: 002 
* Name: Annie Gomez
* UNT Email: anniegomez@my.unt.edu
* Date submitted: April 25, 2022
 
*File name: book.cpp
*Description:  Write  here  an  explanation  of  the  code  that  is  written  in  this  file,  *include  the 
objective of the functions written, any required inputs and the  *correct outputs. This will be an 
explanation in a high level of the code you are *writing in each code file. 
*/ 

#include <iostream>
#include "book.h"
using namespace std;

//default constructor definition

Book::Book(){
	author = "none";
	title = "none";
	ISBN_num = 0;
	libID = 0;
	cost = 0.0;
	status = 'i'; //i stands for in, o stands for out
}

//author set and get
void Book::SetAuthor(string authName){
	author = authName;
}

string Book::GetAuthor(){
	return author;
}

//title set and get
void Book::SetTitle(string bookTitle){
	title = bookTitle;
}

string Book::GetTitle(){
	return title;
}

//ISBN_num set and get
void Book::SetISBN(int theISBN){
	ISBN_num = theISBN;
}

int Book::GetISBN(){
	return ISBN_num;
}

//Library ID set and get
void Book::SetLibID(int theLibID){
	libID = theLibID;
}

int Book::GetLibID(){
	return libID;
}

//cost set and get

void Book::SetCost(double bookCost){
	cost = bookCost;
}

double Book::GetCost(){
	return cost;
}


//status set and get

void Book::SetStatus(char currStatus){
	status = currStatus;
}

char Book::GetStatus(){
	return status;
}


