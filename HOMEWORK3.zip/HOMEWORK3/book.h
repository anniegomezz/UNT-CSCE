/*
* CSCE 1040 Homework 3
* Section: 002
* Name: Annie Gomez
* UNT Email: anniegomez@my.unt.edu
* Date submitted: April 25, 2022

*File name: book.h
*Description: Header for the book class. Includes private data members for the book entity as well as mutators ans accessors. There are no outputs.
*/

#ifndef BOOK_H
#define BOOK_H

#include <string>
using namespace std;

class Book{
	public:
		Book(); //default constructor

//mutators and accessors for the private data members
		void SetAuthor(string authName);
		string GetAuthor();
		void SetTitle(string bookTitle);
		string GetTitle();
		void SetISBN(int theISBN);
		int GetISBN();
		void SetLibID(int theLibID);
		int GetLibID();
		void SetCost(double bookCost);
		double GetCost();
		void SetStatus(char currStatus);
		char GetStatus();

	private:
		string author;
		string title;
		int ISBN_num;
		int libID;
		double cost;
		char status; //either i for in, o for out, r for repair or l for lost

};


#endif

