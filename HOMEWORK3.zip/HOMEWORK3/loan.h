/*
* CSCE 1040 Homework 3
* Section: 002
* Name: Annie Gomez
* UNT Email: anniegomez@my.unt.edu
* Date submitted: April 25, 2022

*File name: loan.h
*Description: Header file for the loan entity. Includes the private data members, the default constructor, as well as mutators and accessors.
There is no output.
*/

#ifndef LOAN_H
#define LOAN_H
#include <iostream>
#include <string>
#include <ctime>
using namespace std;

class Loan{
	public:
		Loan(); //default constructor
//mutators and accessors
		void SetLoanID(int Lid);
		int GetLoanID();
		void SetBookID(int Bid);
		int GetBookID();
		void SetPatronID(int Pid);
		int GetPatronID();
		void SetDueDate(time_t due);
		time_t GetDueDate();
		void SetNumChecks(int plus);
		int GetNumChecks();

	private:
		int LoanID;
		int BookID;
		int PatronID;
		time_t dueDate;
		int numReChecks;
};




#endif
