/* 
* CSCE 1040 Homework 3 
* Section: 002
* Name: Annie Gomez
* UNT Email: anniegomez@my.unt.edu
* Date submitted: April 25, 2022
 
*File name: books.cpp
*Description:  Write  here  an  explanation  of  the  code  that  is  written  in  this  file,  *include  the 
objective of the functions written, any required inputs and the  *correct outputs. This will be an 
explanation in a high level of the code you are *writing in each code file. 
*/ 

#include <iostream>
#include <string>
#include <vector>
#include <iterator>
#include <algorithm>
#include <ctime>
#include <iomanip>
#include "books.h"
using namespace std;

//default constructor definition
Books::Books(){}

//member function definitions

void Books::addBook(){
	string tempAuthor;
	string tempTitle;
	int tempISBN;
	int tempLibID;
	double tempCost;

	cout << "****Adding New Book****" << endl;
	Book tempBook;

	cout << "Enter author name:" << endl;
	cin.ignore();
	getline(cin, tempAuthor);
	tempBook.SetAuthor(tempAuthor);

	cout << "Enter title name:" << endl;
	getline(cin, tempTitle);
	tempBook.SetTitle(tempTitle);

	cout << "Enter ISBN number:" << endl;

	cin >> tempISBN;
	tempBook.SetISBN(tempISBN);

	cout << "Enter Library ID:" << endl;
	cin.ignore();
	cin >> tempLibID;
	tempBook.SetLibID(tempLibID);

	cout << "Enter the cost of the book:" << endl;
	cin.ignore();
	cin >> tempCost;
	tempBook.SetCost(tempCost);

	tempBook.SetStatus('i');

	bVect.push_back(tempBook);
}

void Books::editBook(){
	string editBook;
	string tempAuthor;
	string tempTitle;
	int tempISBN;
	bool editCont = true;
	char editChoice;

	cout << "Enter the title of the book you would like to edit: " << endl;
	cin.ignore();
	getline(cin, editBook);

	for(iter = bVect.begin(); iter != bVect.end(); iter++){
		if((iter->GetTitle()) == editBook){
			cout << "Book Found!" << endl;
			while(editCont == true){
				cout << endl;
				cout << "What would you like to edit?" << endl;
				cout << "a - Book Author" << endl;
				cout << "t - Book Title" << endl;
				cout << "i - Book ISBN" << endl;
				cout << "q - Quit Editing Menu" << endl;
				cout << "Enter the character for the corresponding choice you would like to take: " << endl;

				cin >> editChoice;

				switch(editChoice){

					case 'a':{
						cout << "Enter the new author name." << endl;
						cin.ignore();
						getline(cin, tempAuthor);
						iter->SetAuthor(tempAuthor);
						cout << "Successfully updated author name." << endl;
						break;

					}//end of 'a' (author) case

					case 't':{
						cout << "Enter the new title of the book." << endl;
						cin.ignore();
						getline(cin, tempTitle);
						iter->SetTitle(tempTitle);
						cout << "Successfully updated book title." << endl;
						break;

					}//end of 't' (title) case

					case 'i':{
						cout << "Enter the new ISBN of the book." << endl;
						cin >> tempISBN;
						iter->SetISBN(tempISBN);
						cout << "Successfully udpated book ISBN." << endl;
						break;

					}//end of 'i' (ISBN) case

					case 'q':{
						cout << endl;
						cout << "Exiting Edit Menu" << endl;
						cout << endl;
						editCont = false;
						break;
					}//end of 'q' (quit) case

					default:{
						cout << "Wrong choice. Please try again." << endl;
						break;
					}

				}//end of switch case 
			}//end of while loop
		}else{
			cout << "Book was not found, sorry." << endl;
			break;
		}//if else
	}//for loop
}

void Books::deleteBook(){
	string byeBook;
	cout << "Enter the Title of the Book you want to Delete: " << endl;
	cin.ignore();
	getline(cin, byeBook);
	for(iter = bVect.begin(); iter != bVect.end(); iter++){
		if((iter->GetTitle()) == byeBook){
			bVect.erase(iter);
			cout << byeBook << " deleted successfully." << endl;
			break;
		}
	}
}

void Books::searchBook(){
	string searchTitle;
	cout << "Enter the Title of the Book you want to Find: " << endl;
	cin.ignore();
	getline(cin, searchTitle);

	for(iter = bVect.begin(); iter != bVect.end(); iter++){
		if((iter->GetTitle()) == searchTitle){
			break;
		}
	}

	if(iter != bVect.end()){
		cout << endl;
		cout << searchTitle << " exists in the library." << endl;
		cout << endl;
	}else{
		cout << "Book was not found." << endl;
		cout << endl;
	}

}

void Books::printBook(){
	string searchTitle;
	cout << "Enter the Title of the Book you want to Find: " << endl;
	cin.ignore();
	getline(cin, searchTitle);

	for(iter = bVect.begin(); iter != bVect.end(); iter++){
		if((iter->GetTitle()) == searchTitle){
			cout << endl;
			cout << "*****BOOK INFORMATION*****" << endl;
			cout << "Book Title: " << iter->GetTitle() << endl;
			cout << "Author Name: " << iter->GetAuthor() << endl;
			cout << "ISBN: " << iter->GetISBN() << endl;
			cout << "Library ID: " << iter->GetLibID() << endl;
			cout << "Book Cost: " << iter->GetCost() << endl;
			if((iter->GetStatus()) == 'i'){
				cout << "Current Status: IN" << endl;
			}else if((iter->GetStatus()) == 'o'){
				cout << "Current Status: OUT" << endl;
			}else if((iter->GetStatus()) == 'r'){
				cout << "Current Status: REPAIR" << endl;
			}else{
				cout << "Current Status: LOST" << endl;
			}
		}//first if
	}//for loop
			cout << endl;
}//print book

void Books::printAllBooks(){
	if(bVect.empty() == true){
		cout << "There are no books in the library." << endl;
	}else{
        for(iter = bVect.begin(); iter != bVect.end(); iter++){ 
		cout << endl;
		cout << "*****BOOK LIBRARY*****" << endl;
                cout << "Book Title: " << iter->GetTitle() << endl;
                cout << "Author Name: " << iter->GetAuthor() << endl;
                cout << "ISBN: " << iter->GetISBN() << endl; 
                cout << "Library ID: " << iter->GetLibID() << endl;
                cout << "Book Cost: " << iter->GetCost() << endl;
		if((iter->GetStatus()) == 'i'){
			cout << "Current Status: IN" << endl;
		}else if((iter->GetStatus()) == 'o'){
			cout << "Current Status: OUT" << endl;
		}else if((iter->GetStatus()) == 'r'){
			cout << "Current Status: REPAIR" << endl;
		}else{
			cout << "Current Status: LOST" << endl;
		}
		cout << endl;
        }//for loop
	}//if
}




