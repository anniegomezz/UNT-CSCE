/*
* CSCE 1040 Homework 3
* Section: 002
* Name: Annie Gomez
* UNT Email: anniegomez@my.unt.edu
* Date submitted: April 25, 2022

*File name: main.cpp
*Description:  Write  here  an  explanation  of  the  code  that  is  written  in  this  file,  *include  the 
objective of the functions written, any required inputs and the  *correct outputs. This will be an 
explanation in a high level of the code you are *writing in each code file.
*/

#include <iostream>
#include <string>
#include <iterator>
#include <algorithm>
#include <ctime>
#include <iomanip>
#include "book.h"
#include "books.h"
#include "patron.h"
#include "patrons.h"
#include "loan.h"
#include "loans.h"
using namespace std;

int main(){

	Books BookLib;
	Patrons PatronLib;
	Loans LoansLib;
	char option; //holds character for menu choice
	bool cont = true; //boolean that makes while loop continue
//implementing menu
	while(cont == true){
		cout << "***MENU***" << endl;
		cout << "b - Book Menu" << endl;
		cout << "p - Patron Menu" << endl;
		cout << "l - Loan Menu" << endl;
		cout << "q - Quit" << endl;

		cout << endl;
		//prompt user to choose an option from the menu
		cout << "Enter the corresponding character for the menu you wish to browse:" << endl;
		cin >> option;

		switch(option){
			case 'b':{//BOOK MENU
				bool bookCont = true;
				char bookOption;
				while(bookCont == true){
				cout << "***BOOK MENU***" << endl;
				cout << "a - Add New Book" << endl;
				cout << "e - Edit Existing Book" << endl;
				cout << "d - Delete Book" << endl;
				cout << "s - Search for Book" << endl;
				cout << "p - Print Information for a Book" << endl;
				cout << "l - Print List of All Books" << endl;
				cout << "q - Quit Book Menu" << endl;

				cout << endl;
				cout << "Enter the corresponding character for the action you want to take." << endl;
				cin >> bookOption;
				switch(bookOption){

					case 'a':{
						BookLib.addBook();
						break;
					}//end of 'a' (add) case

					case 'e':{
						BookLib.editBook();
						break;
					}//end of 'e' (edit) case

					case 'd':{
						BookLib.deleteBook();
						break;
					}//end of 'd' (delete) case

					case 's':{
						BookLib.searchBook();
						break;
					}//end of 's' (search) case
					case 'p':{
						BookLib.printBook();
						break;
					}//end of 'p' (print info for one book) case

					case 'l':{
						BookLib.printAllBooks();
						break;
					}// end of 'l' (list all books) case

					case 'q':{
						cout << "Exiting Book Menu" << endl;
						bookCont = false;
						break;
					}
					default:{
						cout << "Wrong choice. Please try again." << endl;
						break;
					}
				}//end of switch case


				}//end of while loop
				break;
			}//end of book menu

			case 'p':{//PATRON MENU
				bool patronCont = true;
				char patronOption;
				while(patronCont == true){
				cout << "***PATRON MENU***" << endl;
				cout << "a - Add New Patron" << endl;
				cout << "e - Edit Patron Information" << endl;
				cout << "d - Delete Patron" << endl;
				cout << "s - Search for Patron" << endl;
				cout << "p - Print Information for a Patron" << endl;
				cout << "l - Print List of All Patrons" << endl;
				cout << "q - Quit Book Menu" << endl;

				cout << endl;
				cout << "Enter the corresponding character for the option you wish to take." << endl;
				cin >> patronOption;
				switch(patronOption){

					case 'a':{
						PatronLib.addPatron();
						break;
					}//end of 'a' (add) case

					case 'e':{
						PatronLib.editPatron();
						break;
					}//end of 'e' (edit patron) case

					case 'd':{
						PatronLib.deletePatron();
						break;
					}//end of 'd' (delete patron) case

					case 's':{
						PatronLib.searchPatron();
						break;
					}//end of 's' (search) case

					case 'p':{
						PatronLib.printPatron();
						break;
					}//end of 'p' (print for patron info) case

					case 'l':{
						PatronLib.printAllPatrons();
						break;
					}//end of 'l' (list all patrons) case

					case 'q':{
						cout << "Exiting Patron Menu" << endl;
						patronCont = false;
						break;
					}
					default:{
						cout << "Wrong choice. Please try again." << endl;
						break;
					}
				}

				}//end of while loop
				break;
			}//end of patron menu

			case 'l':{//LOAN MENU
				bool loanCont = true;
				char loanOption;
				while(loanCont == true){
				cout << "***LOAN MENU***" << endl;
				cout << "o - Checkout Book" << endl;
				cout << "i - Checkin Book" << endl;
				cout << "d - List All Overdue Books" << endl;
				cout << "p - List All Patron Loans" << endl;
				cout << "u - Update Loan Status" << endl;
				cout << "r - Recheck Book" << endl;
				cout << "e - Edit Loan" << endl;
				cout << "l - Report Lost" << endl;
				cout << "q - Quit Loan Menu" << endl;

				cout << endl;
				cout << "Enter the corresponding character for the option you wish to take." << endl;
				cin >> loanOption;
				switch(loanOption){

					case 'o':{
						LoansLib.checkoutBook();
						break;
					}//end of 'o' (checkout book) case

					case 'i':{
						LoansLib.checkinBook();
						break;
					}//end of 'i' (checkin book) case

					case 'd':{
						LoansLib.listAllOverdue();
						break;
					}//end of 'd' (list overdue) case

					case 'p':{
						LoansLib.listPatronLoans();
						break;
					}//end of 'p' (list all patron loans) case
					case 'u':{
						LoansLib.updateLoanStatus();
						break;
					}//end of 'u' (update loan status) case

					case 'r':{
						LoansLib.recheckBook();
						break;
					}//end of 'r' (recheck book) case

					case 'e':{
						LoansLib.editLoan();
						break;
					}//end of 'e' (edit loan) case

					case 'l':{
						LoansLib.reportLost();
						break;
					}//end of 'l' (report lost) case

					case 'q':{
						cout << "Exiting Loan Menu" << endl;
						loanCont = false;
						break;
					}
					default:{
						cout << "Wrong choice. Please try again." << endl;
						break;
					}

				}//end of switch case

				}//end of while loop
				break;
			}

			case 'q':{
				cout << "Thank you! Have a nice day!" << endl;
				cont = false;
				break;
			}

			default:{
				cout << "Wrong choice. Please choose an option." << endl;
				break;
			}
		}
}


return 0;
}
