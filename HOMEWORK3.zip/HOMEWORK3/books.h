/*
* CSCE 1040 Homework 3
* Section: 002
* Name: Annie Gomez
* UNT Email: anniegomez@my.unt.edu
* Date submitted: April 25, 2022

*File name: books.h
*Description:  Write  here  an  explanation  of  the  code  that  is  written  in  this  file,  *include  the 
objective of the functions written, any required inputs and the  *correct outputs. This will be an 
explanation in a high level of the code you are *writing in each code file.
*/
#ifndef BOOKS_H
#define BOOKS_H

#include <iostream>
#include <string>
#include <vector>
#include <iterator>
#include "book.h"
using namespace std;

class Books{
//vector to hold collection of Book objects
	vector<Book> bVect;
	vector<Book>::iterator iter;

	public:
//default constructor
		Books();
//functions for editing the collection of Book objects
		void addBook();
		void editBook();
		void deleteBook();
		void searchBook();
		void printBook();
		void printAllBooks();

};

#endif
