/* 
* CSCE 1040 Homework 3 
* Section: 002 
* Name: Annie Gomez
* UNT Email: anniegomez@my.unt.edu
* Date submitted: April 25, 2022
 
*File name: loans.h
*Description:  Write  here  an  explanation  of  the  code  that  is  written  in  this  file,  *include  the 
objective of the functions written, any required inputs and the  *correct outputs. This will be an 
explanation in a high level of the code you are *writing in each code file. 
*/ 

#ifndef LOANS_H
#define LOANS_H

#include <iostream>
#include <string>
#include <vector>
#include "loan.h"
using namespace std;

class Loans{
//vector to hold collection of Loan objects
	vector <Loan> lVect;
	vector <Loan>::iterator iter;
	public:
//default constructor
	Loans();
//functions for editing the collection of Loan objects
	void checkoutBook();
	void checkinBook();
	void listAllOverdue();
	void listPatronLoans();
	void updateLoanStatus();
	void recheckBook();
	void editLoan();
	void reportLost();


};

#endif
