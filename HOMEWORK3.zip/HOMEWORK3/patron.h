/*
* CSCE 1040 Homework 3
* Section: 002
* Name: Annie Gomez
* UNT Email: anniegomez@my.unt.edu
* Date submitted: April 25, 2022

*File name: patron.h
*Description: Header file for the patron entity. Includes default constructor, private data members,
as well as mutators and accessors. Has no output.
*/

#ifndef PATRON_H
#define PATRON_H

#include <string>
using namespace std;

class Patron{
	public:
		Patron();
//mutators and accessors for the private data members
		void SetName(string pName);
		string GetName();
		void SetPatronID(int pID);
		int GetPatronID();
		void SetBalance(double pBalance);
		double GetBalance();
		void SetBooksOut(int numBooks);
		int GetBooksOut();

	private:
		string name;
		int patronID;
		double balance;
		int booksOut;

};



#endif
