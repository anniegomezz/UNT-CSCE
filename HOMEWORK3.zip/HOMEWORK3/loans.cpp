/* 
* CSCE 1040 Homework 3 
* Section: 002 
* Name: Annie Gomez
* UNT Email: anniegomez@my.unt.edu
* Date submitted: April 25, 2022
 
*File name: loans.cpp
*Description:  Write  here  an  explanation  of  the  code  that  is  written  in  this  file,  *include  the 
objective of the functions written, any required inputs and the  *correct outputs. This will be an 
explanation in a high level of the code you are *writing in each code file. 
*/ 

#include <iostream>
#include <string>
#include <vector>
#include <iterator>
#include <algorithm>
#include <ctime>
#include <iomanip>
#include "loans.h"
using namespace std;

//default constructor definition
Loans::Loans(){}

//member function definitions

void Loans::checkoutBook(){
	cout << endl;
	cout << "Service currently unavailable. Please try again later." << endl;
	cout << endl;
}

void Loans::checkinBook(){
	cout << endl;
	cout << "Service currently unavailable. Please try again later." << endl;
	cout << endl;
}

void Loans::listAllOverdue(){
	cout << endl;
	cout << "Service currently unavailable. Please try again later." << endl;
	cout << endl;
}

void Loans::listPatronLoans(){
	cout << endl;
	cout << "Service currently unavailable. Please try again later." << endl;
	cout << endl;
}

void Loans::updateLoanStatus(){
	cout << endl;
	cout << "Service currently unavailable. Please try again later." << endl;
	cout << endl;
}

void Loans::recheckBook(){
	cout << endl;
	cout << "Service currently unavailable. Please try again later." << endl;
	cout << endl;
}

void Loans::editLoan(){
	cout << endl;
	cout << "Service currently unavailable. Please try again later." << endl;
	cout << endl;
}

void Loans::reportLost(){
	cout << endl;
	cout << "Service currently unavailable. Please try again later." << endl;
	cout << endl;
}


